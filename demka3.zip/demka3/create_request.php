<?php
session_start();
include 'db.php';
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Проверка наличия всех полей
    if (
        empty($_POST['sender']) ||
        empty($_POST['receiver']) ||
        empty($_POST['pickup']) ||
        empty($_POST['delivery']) ||
        empty($_POST['weight']) ||
        empty($_POST['volume']) ||
        empty($_POST['transport']) ||
        empty($_POST['payment'])
    ) {
        $error = "Все поля обязательны для заполнения.";
    } else {
        $sender     = $_POST['sender'];
        $receiver   = $_POST['receiver'];
        $pickup     = $_POST['pickup'];
        $delivery   = $_POST['delivery'];
        $weight     = $_POST['weight'];
        $volume     = $_POST['volume'];
        $transport  = $_POST['transport'];
        $payment    = $_POST['payment'];

        // Подготовка запроса
        $stmt = $conn->prepare("
            INSERT INTO requests 
            (user_id, sender_address, receiver_address, pickup_datetime, delivery_datetime, weight, volume, transport_type, payment_method, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Новая')
        ");

        if (!$stmt) {
            die("Ошибка подготовки запроса: " . $conn->error);
        }

        // Привязка параметров
        $stmt->bind_param("isssssdss", $_SESSION['user_id'], $sender, $receiver, $pickup, $delivery, $weight, $volume, $transport, $payment);

        // Выполнение запроса
        if (!$stmt->execute()) {
            die("Ошибка выполнения запроса: " . $stmt->error);
        }

        // Перенаправление после успешного добавления
        header("Location: dashboard.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="ru">

<body style="margin: 30px">
<h2>Создать заявку</h2>

<?php if ($error): ?>
    <div style="color:red;"><?= $error ?></div>
<?php endif; ?>

<form class="col-md-4" method="post">
    <input class="form-control" type="text" name="sender" placeholder="Адрес отправителя" value="<?= htmlspecialchars($_POST['sender'] ?? '') ?>" required><br>
    <input class="form-control" type="text" name="receiver" placeholder="Адрес получателя" value="<?= htmlspecialchars($_POST['receiver'] ?? '') ?>" required><br>
    <input class="form-control" type="datetime-local" name="pickup" value="<?= htmlspecialchars($_POST['pickup'] ?? '') ?>" required><br>
    <input class="form-control" type="datetime-local" name="delivery" value="<?= htmlspecialchars($_POST['delivery'] ?? '') ?>" required><br>
    <input class="form-control" type="number" step="0.01" name="weight" placeholder="Вес груза (кг)" value="<?= htmlspecialchars($_POST['weight'] ?? '') ?>" required><br>
    <input class="form-control" type="number" step="0.01" name="volume" placeholder="Объем груза (м³)" value="<?= htmlspecialchars($_POST['volume'] ?? '') ?>" required><br>
    <input class="form-control" type="text" name="transport" placeholder="Наименование транспорта" value="<?= htmlspecialchars($_POST['transport'] ?? '') ?>" required><br>
    <label><input class="form-check-input" type="radio" name="payment" value="Наличные" <?= (!isset($_POST['payment']) || $_POST['payment'] === 'Наличные') ? 'checked' : '' ?>> Наличные</label>
    <label><input class="form-check-input" type="radio" name="payment" value="Безналичный" <?= (isset($_POST['payment']) && $_POST['payment'] === 'Безналичный') ? 'checked' : '' ?>> Безналичный</label><br>

    <button class="btn btn-success" style="margin-top: 4px" type="submit">Отправить заявку</button>
</form>
</body>
</html>