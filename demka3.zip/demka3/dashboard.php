<?php
session_start();
include 'db.php';
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM requests WHERE user_id = $user_id");
?>

<!DOCTYPE html>
<html lang="ru">
<head><meta charset="UTF-8"><title>Личный кабинет</title></head>
<body style="margin:20px ">
<h2>Привет, <?= $_SESSION['user_name'] ?></h2>

<div style="display: flex; margin-bottom: 4px; align-items: center">
    <h3>Ваши заявки:</h3>
    <a  style="margin-left: 5px" class="btn btn-success" href="create_request.php">Создать заявку</a>
</div>
<div class="col-md-4">
        <table class="table table-bordered">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Адресс отправителя</th>
                <th scope="col">Адресс получателя</th>
                <th scope="col">Дата отправки</th>
                <th scope="col">Дата получения</th>
                <th scope="col">Вес груза</th>
                <th scope="col">Обьем груза</th>
                <th scope="col">Наименование транспорта</th>
                <th scope="col">Статус</th>
            </tr>
            </thead>
            <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <th><?= htmlspecialchars($row['id']) ?></th>
                    <td><?= htmlspecialchars($row['sender_address']) ?></td>
                    <td><?= htmlspecialchars($row['receiver_address']) ?></td>
                    <td><?= htmlspecialchars($row['pickup_datetime']) ?></td>
                    <td><?= htmlspecialchars($row['delivery_datetime']) ?></td>
                    <td><?= htmlspecialchars($row['weight']) ."кг" ?></td>
                    <td><?= htmlspecialchars($row['volume']) . "м³"?></td>
                    <td><?= htmlspecialchars($row['transport_type']) ?></td>
                    <td><?= htmlspecialchars($row['status']) ?></td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
</div>
<ul>

</ul>

<a class="btn btn-danger" href="logout.php">Выход</a>
</body>
</html>

