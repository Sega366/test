<?php
session_start();
include 'db.php';

if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $request_id = $_POST['request_id'];
    $status = $_POST['status'];
    $reason = $_POST['reason'] ?? '';

    $stmt = $conn->prepare("UPDATE requests SET status = ?, reason = ? WHERE id = ?");
    $stmt->bind_param("ssi", $status, $reason, $request_id);
    $stmt->execute();
}

$result = $conn->query("SELECT r.*, u.name FROM requests r JOIN usersi u ON r.user_id = u.id");
?>

<!DOCTYPE html>
<html lang="ru">
<head><meta charset="UTF-8"><title>Панель администратора</title></head>
<body>
<h2>Заявки</h2>
<table border="1">
    <tr><th>Клиент</th><th>Тип транспорта</th><th>Статус</th><th>Действие</th></tr>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= $row['name'] ?></td>
        <td><?= $row['transport_type'] ?></td>
        <td><?= $row['status'] ?></td>
        <td>
            <form method="post">
                <input type="hidden" name="request_id" value="<?= $row['id'] ?>">
                <select name="status">
                    <option value="в пути">в пути</option>
                    <option value="выполнено">выполнено</option>
                    <option value="отменено">отменено</option>
                </select>
                <input type="text" name="reason" placeholder="Причина отмены">
                <button type="submit">Обновить</button>
            </form>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
<a href="logout.php">Выход</a>
</body>
</html>