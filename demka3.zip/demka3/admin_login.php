<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = $_POST['login'];
    $password = $_POST['password'];

    if ($login === 'adminka' && $password === 'password') {
        $_SESSION['admin'] = true;
        header("Location: admin_panel.php");
        exit;
    } else {
        $error = "Неверный логин или пароль.";
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head><meta charset="UTF-8"><title>Вход администратора</title></head>
<body>
<h2>Вход администратора</h2>
<form method="post">
    <input type="text" name="login" placeholder="adminka" required><br>
    <input type="password" name="password" placeholder="password" required><br>
    <button type="submit">Войти</button>
</form>
</body>
</html>